$Agent="AttachmentManager"
$Factory="AttachmentManager.Factory"
$Path="C:\Program Files\Microsoft\Exchange Server\V14\TransportRoles\agents\AeroFS\AttachmentManager2010.dll"

Install-TransportAgent -Name $Agent -TransportAgentFactory $Factory -AssemblyPath $Path
Enable-TransportAgent -Identity $Agent
Restart-Service MSExchangeTransport
