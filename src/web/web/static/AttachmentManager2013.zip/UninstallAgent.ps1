$Agent="AttachmentManager"

Disable-TransportAgent $Agent
Uninstall-TransportAgent $Agent

Restart-Service MSExchangeTransport
